# Novie V7 Beta

**Know yourself. Grow together.**

This is the V7 Experience Beta built from the V5 foundation and expanded Novie vision.

## Included
- Welcome/onboarding
- Today experience + daily Novie thought
- Personal profile and gradual discovery
- Check-ins, mood/energy/stress tracking
- Growth XP, leaves, streaks
- Connections and compatibility experience
- Communication Lab
- Family area
- Kids 3-minute reset activities
- Astrology exploration
- Science/relationship learning
- Games
- Pattern insights
- Privacy-aware local profile controls

## Current architecture
This beta is intentionally dependency-free: HTML + CSS + JavaScript + localStorage. It can be hosted on GitHub Pages and opened from a phone or computer.

## Important beta note
The app currently stores demo data locally in the browser. It does not yet provide real multi-user accounts, secure cloud sync, live AI API calls, real invitations/notifications, production astrology calculations, or live places/events data. Those are the next infrastructure layers after the experience is validated with testers.
