# V6 Build Notes
This is a front-end prototype foundation, not yet a production app. It does not yet include real accounts, cloud database, AI API keys, push notifications, geolocation, ads, payments, moderation, or app-store packaging.

Next production modules:
1. Authentication and profiles.
2. Database and relationship/family permissions.
3. AI service with safety controls and personalized context.
4. Evidence-based relationship content with source tracking.
5. Astrology/lunar calculation service.
6. Opt-in push notifications.
7. Secure child/family permissions and age-appropriate experiences.
8. Nearby activity/event integrations.
9. Moderation, blocking, reporting, privacy and safety.
10. Analytics and retention measurement.
11. Ads/rewarded ads only after the core experience is enjoyable.
12. iOS/Android packaging.
