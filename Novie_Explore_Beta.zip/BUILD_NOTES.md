# Novie Explore Beta Build Notes

The current product is an evolving Novie build, not a V5/V6 release. The uploaded ZIP filename is retained only for source continuity.

## This build focuses on
1. Making the current design genuinely explorable.
2. Turning Play into a multi-round experience.
3. Surfacing optional astrology.
4. Letting users create and explore private beta connections.
5. Preserving the colorful, warm, playful identity.
6. Keeping science/evidence and astrology clearly separated.
7. Adding PWA install support.

## Production layers still ahead
1. Authentication and cloud profiles.
2. Database and relationship/family permissions.
3. Real AI service with safety controls and personalized context.
4. Evidence-based relationship content with source tracking.
5. Real astrology/lunar calculation engine for Moon/Rising/full charts.
6. Opt-in push notifications.
7. Secure child/family permissions and age-appropriate experiences.
8. Nearby activity/event integrations.
9. Moderation, blocking, reporting, privacy and safety.
10. Analytics and retention measurement.
11. Tasteful ads/rewarded ads only after the core experience is enjoyable.
12. iOS/Android packaging.
