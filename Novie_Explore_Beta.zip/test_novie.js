const fs = require('fs');
const html = fs.readFileSync(__dirname + '/index.html','utf8');
function assert(condition, message){ if(!condition) throw new Error(message); }

// RED tests: the current foundation should fail these until the exploration layer is expanded.
const playBlock = html.match(/const gameQuestions=\{([\s\S]*?)\n\};/)?.[1] || '';
const wouldYouRatherQuestions = (playBlock.match(/'Would You Rather':\[([\s\S]*?)\],\n/)?.[1] || '').match(/\[[^\]]+\]/g) || [];
assert(wouldYouRatherQuestions.length >= 8, 'Would You Rather needs at least 8 playable questions.');
assert(/startGame/.test(html) && /renderGameRound/.test(html) && /answerGame/.test(html), 'Play needs a clear multi-round loop.');

const astrologyBlock = html.match(/function openAstrology\(\)\{([\s\S]*?)\nfunction showMoon/)?.[1] || '';
assert(/Birth chart/.test(astrologyBlock), 'Astrology needs a discoverable birth chart entry.');
assert(/Daily astrology/.test(astrologyBlock), 'Astrology needs a daily astrology entry.');
assert(/Astrology settings|Turn astrology off|astrology=!state\.astrology/.test(astrologyBlock), 'Astrology needs an on/off control.');

assert(/function openProfile\(\)/.test(html), 'Profile flow must remain available.');
assert(/localStorage/.test(html), 'The prototype must preserve local state for exploration.');
assert(/function openConnections\(\)/.test(html), 'Connections exploration must remain available.');
assert(/function openGames\(\)/.test(html), 'Play hub must remain available.');

console.log('All Novie exploration tests passed.');

assert(/function openConnectionDetail\(i\)/.test(html), 'Connections need an explorable detail view.');
assert(/serviceWorker\.register\('\.\/sw\.js'\)/.test(html), 'The beta should register its service worker for installable app behavior.');
assert(/"icons"/.test(fs.readFileSync(__dirname + '/manifest.json','utf8')), 'Manifest should include an app icon.');
