# Novie V6 Master Specification

HOME
- Personalized morning encouragement and AI-generated inspirational messages.
- Quick mood check-in and "What do I need?" choices.
- 30-second, 2-minute, 5-minute, Play, Astrology, Work on Something, and Surprise Me paths.
- Today's Next Step, XP, streak, level, progress preview.
- Gentle stop-anytime behavior.

PERSONALIZED AI
- Generate multiple options, not one recommendation.
- Adapt to mood, recent check-ins, goals, interests, relationships, and enabled astrology.
- Examples for a low/comfort user: one-breath reset, tiny next-hour goal, supportive message, calming activity, private talk.
- Never shame or pressure.

COMMUNICATION LAB
- Hard conversations, apologies, boundaries, reassurance, conflict repair, appreciation, money, intimacy, parenting/co-parenting, long-distance, friendship.
- Multiple AI communication styles: Gentle, Direct, Loving, Firm Boundary, Short Text, Repair-focused.

RELATIONSHIPS
- Dating, committed relationships, marriage, friendship, family, custom connections.
- Compatibility is multi-factor: communication, values, goals, emotional needs, lifestyle, conflict/repair, interests, boundaries, optional astrology.

ASTROLOGY
- Prominent but optional.
- Sun, Moon, Rising, birth date/time/location, full birth chart.
- Daily horoscope.
- Moon phases: New Moon, First Quarter, Full Moon, Last Quarter.
- Traditional astrology interpretations for signs/placements during lunar periods.
- Dating, friendship, relationship/synastry compatibility.
- Clear separation of evidence-based insights and astrology interpretations.
- Astrology can be turned off.

GAMES
- Daily questions, this-or-that, guess their answer, appreciation, memory games, quizzes.
- Long-distance turn-taking.
- "Your person answered. It's your turn."
- Shared XP and streaks.

DISCOVER
- Interest discovery: dancing, pottery, hiking, fitness, food, music, gaming, books, art, crafts, outdoors, travel, sports, volunteering, etc.
- Nearby activities/events/places and people with shared interests, with safety/privacy controls.

FAMILY + KIDS
- Family hub and parent/child/relative connections.
- Kids can use a trusted adult's phone for 3-5 minute check-ins.
- Playful calming activities, never homework.
- Parent trends over time without diagnosing.
- Nana/relatives can participate.
- Co-parenting area when applicable.

PROGRESS
- XP, levels, streaks, badges, communication/connection/self-awareness/goal/relationship trends, graphs and milestones.

NOTIFICATIONS
- Turn-based games, connection activity, encouragement, streaks, astrology/lunar updates, progress milestones.
- Invitations, not nagging.

MONETIZATION
- Core experience can remain free.
- Future options: tasteful/rewarded ads, local partnerships, sponsored activities, affiliate/referral revenue, optional premium depth, Novie Professionals.
