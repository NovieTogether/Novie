# Novie — Explore Beta

**Know Yourself. Grow Together.**

This build keeps the warm, colorful Novie foundation and expands it into a much more explorable browser/PWA beta. It is no longer treated as a V5/V6 product version; the ZIP filename is only a source artifact.

## What is new in this beta
- Daily changing Novie encouragements.
- A real multi-round Play experience with 12 games and multiple questions per game.
- Would You Rather now has 12 rounds instead of ending after one or two questions.
- Play history, XP, leaves, and a simple Play Explorer badge.
- Astrology is visible from the home screen and has an on/off switch.
- Astrology profile with birth date, optional time/place, Sun sign, moon-phase reflections, daily astrology, compatibility exploration, and moon journal.
- Clear separation between astrology as a reflective tradition and evidence-based Novie features.
- My People can now create private beta connections and open a connection detail view.
- Connection detail links into games, communication, compatibility, growth prompts, and Discover.
- MAGI has a richer exploration snapshot.
- Discover has more activity ideas.
- Responsive mobile/desktop layout is preserved.
- Added a basic PWA manifest/service worker so the beta can be installed from a supporting browser after deployment.

## Current beta limitations
This is still a front-end beta. Real accounts, cloud sync, real invitations, production AI, precise astronomical birth-chart calculations, live local events, push notifications, moderation, secure family/child permissions, ads, payments, and App Store/Google Play packaging require later production services.

## Local state
The beta stores exploration data in browser localStorage. Clearing browser site data resets the local beta profile.
